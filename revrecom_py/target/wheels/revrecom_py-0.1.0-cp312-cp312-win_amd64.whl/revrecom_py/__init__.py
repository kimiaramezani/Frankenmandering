from .revrecom_py import *

__doc__ = revrecom_py.__doc__
if hasattr(revrecom_py, "__all__"):
    __all__ = revrecom_py.__all__